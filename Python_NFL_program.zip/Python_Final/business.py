from dataclasses import dataclass

@dataclass
class TeamClass:
    teamID:str = ""
    teamName:str = ""
    wins:int = 0
    losses:int = 0
    ties:int = 0
    passAtt:int = 0
    passCmp:int = 0
    passYards:int = 0
    passTD:int = 0
    passINT:int = 0
    
    @property
    def totalGames(self):
        totalGames = self.wins + self.losses + self.ties
        return totalGames

    @property
    def winPerc(self):
        try:
            winPerc = self.wins / self.totalGames
            return round(winPerc, 3)
        except ZeroDivisionError:
            return 0.0

    @property
    def cmpPerc(self):
        try:
            cmpPerc = self.passCmp / self.passAtt
            return round(cmpPerc * 100, 1)
        except ZeroDivisionError:
            return 0.0

    @property
    def yardsPerAtt(self):
        try:
            yardsPerAtt = self.passYards / self.passAtt
            return round(yardsPerAtt, 1)
        except ZeroDivisionError:
            return 0.0

def main():
    pass

if __name__ == "__main__":
    main()

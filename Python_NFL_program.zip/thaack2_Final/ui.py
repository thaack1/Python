"""
This program is used for NFL NFC North teams to
add a team's stats, remove a team's stats,
edit a team's stats, and display all team's stats.
It also interacts with a SQLite database to store the data.

Written by:     Tyler Haack
Date created:   12/12/2023
Date modified:  12/13/2023
"""

import db
from business import TeamClass

def add_team(teams):    
    teamID = input("NFL team abbreviation: ").upper()
    teamName = input("NFL team name: ").title()
    print()
    wins, losses, ties = get_record()
    passAtt = get_passAtt()
    passCmp = get_passCmp(passAtt)
    passYards = get_passYards()
    passTD = get_passTD()
    passINT = get_passINT()

    # Define what the team object is using the TeamClass class
    team = TeamClass(teamID, teamName, wins, losses, ties, passAtt, passCmp,
                     passYards, passTD, passINT)
    
    teams.append(team)  # Add the new team to the teams list
    db.add_team(team)   # Add the new team as a whole record in the DB
    print(f"{team.teamID} {team.teamName} were added.\n")

def get_record():
    while True:
        print("Enter the record of the team (total must be 17 or less)...")
        try:
            wins = int(input("Wins: "))
            losses = int(input("Losses: "))
            ties = int(input("Ties: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue
        
        record = int(wins + losses + ties)
        print(f"Total: {record}\n")
    
        if record > 17:
            print("The total games are more than 17. "
                  "Please re-enter all values.\n")
        else:
            return wins, losses, ties

def get_passAtt():
    while True:
        try:
            passAtt = int(input("Pass attempts: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if passAtt < 0 or passAtt > 1000:    
            print("Invalid entry. Must be from 0 to 1,000.")
        else:
            return passAtt

def get_passCmp(passAtt):
    while True:
        try:
            passCmp = int(input("Pass completions: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if passCmp < 0 or passCmp > passAtt:    
            print(f"Invalid entry. Must be from 0 to {passAtt}.")
        else:
            return passCmp
def get_passYards():
    while True:
        try:
            passYards = int(input("Pass yards: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if passYards < 0 or passYards > 7500:    
            print("Invalid entry. Must be from 0 to 7,500.")
        else:
            return passYards

def get_passTD():
    while True:
        try:
            passTD = int(input("Pass touchdowns: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if passTD < 0 or passTD > 75:    
            print("Invalid entry. Must be from 0 to 75.")
        else:
            return passTD

def get_passINT():
    while True:
        try:
            passINT = int(input("Pass interceptions: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if passINT < 0 or passINT > 75:    
            print("Invalid entry. Must be from 0 to 75.")
        else:
            return passINT

def get_teamID(teams, prompt):
    while True:
        teamID = input(prompt).upper()
        if not any(team.teamID == teamID for team in teams):
            print("Invalid team abbreviation. Please try again.")
        else:
            return teamID

def delete_team(teams):
    teamID = get_teamID(teams, "NFL team abbreviation: ")

    # Find the index of the team with the matching teamID
    team_index = next((index for index, team in enumerate(teams)
                       if team.teamID == teamID), None)
    
    team = teams.pop(team_index) #Remove team whose teamID is at the index
    db.delete_team(team)        #Delete the team's row within the DB
    print(f"{team.teamID} {team.teamName} were deleted.\n")

def edit_team_info(teams):
    teamID = get_teamID(teams, "NFL team abbreviation: ")

    # Find the team with the matching teamID
    team = next((team for team in teams if team.teamID == teamID), None)
    
    print(f"You selected {team.teamID} {team.teamName}.\n")
    print("Select a stat to edit. Enter DONE when finished.\n"
          "REC\t= Wins, Losses, and Ties\n"
          "ATT\t= Pass attempts\n"
          "CMP\t= Pass completions\n"
          "YARDS\t= Pass yards\n"
          "TD\t= Pass touchdowns\n"
          "INT\t= Pass interceptions\n")
    while True:
        edit_field = input("Stat: ").upper()
        if edit_field == "REC":
            team.wins, team.losses, team.ties = get_record()
        elif edit_field == "ATT":
            team.passAtt = get_passAtt()
        elif edit_field == "CMP":
            passAtt = team.passAtt
            team.passCmp = get_passCmp(passAtt)
        elif edit_field == "YARDS":
            team.passYards = get_passYards()
        elif edit_field == "TD":
            team.passTD = get_passTD()
        elif edit_field == "INT":
            team.passINT = get_passINT()
        elif edit_field == "DONE":
            break
        else:
            print("Not a valid option. Please try again.\n")
    
    db.update_team(team) #Update the team's row within the DB
    print(f"{team.teamID} {team.teamName} were updated.\n")

def display_teams(teams):
    if teams == None:
        print("There are currently no teams.")        
    else:
        print(f"{'Team'}\t{'W'}   {'L'}   {'T'}   {'Win %'}\t" + \
              f"{'ATT'}   {'CMP'}   {'Cmp %'}\t{'Yards'}\t" + \
              f"{'YPA'}\t{'TD'}   {'INT'}")
        print("-" * 80)
        for team in teams:
            print(f"{team.teamID}\t{team.wins}   " + \
                  f"{team.losses}   {team.ties}   {team.winPerc}\t" + \
                  f"{team.passAtt}   {team.passCmp}   {team.cmpPerc}\t" + \
                  f"{team.passYards}\t{team.yardsPerAtt}\t" + \
                  f"{team.passTD}   {team.passINT}")
    print()   

def display_separator():
    print("=" * 80)

def display_title():
    print("                   NFL NFC North Team Statistics")

def display_menu():
    print("MENU OPTIONS")
    print("1 – Display teams")
    print("2 – Add team")
    print("3 – Remove team")
    print("4 – Edit team info")
    print("5 – Display menu")
    print("6 - Exit program")
    print()

def main():
    display_separator()
    display_title()
    display_menu()

    db.connect()
    teams = db.get_teams() # Retrieve existing records in DB table

    display_separator()
    
    while True:
        try:
            option = int(input("Menu option: "))
        except ValueError:
            option = -1
        print()
        if option == 1:
            display_teams(teams)
        elif option == 2:
            add_team(teams)
            teams = db.get_teams()  # Refresh to match DB table
        elif option == 3:
            delete_team(teams)
        elif option == 4:
            edit_team_info(teams)
        elif option == 5:
            display_menu()
        elif option == 6:
            db.close()
            print("Bye!")
            break
        else:
            print("Not a valid option. Please try again.\n")
            display_menu()

if __name__ == "__main__":
    main()

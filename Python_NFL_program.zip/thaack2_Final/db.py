import sqlite3
from contextlib import closing

from business import TeamClass

conn = None

def connect():
    global conn
    if not conn:
        DB_FILE = "Final.sqlite"
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row

def close():
    if conn:
        conn.close()

def make_team(row):
    return TeamClass(row["teamID"], row["teamName"], row["wins"], row["losses"],
                     row["ties"], row["passAtt"], row["passCmp"],
                     row["passYards"], row["passTD"], row["passINT"])

def get_teams():    
    query = '''SELECT teamID, teamName, wins, losses, ties, passAtt, passCmp,
                     passYards, passTD, passINT
               FROM Teams'''
    with closing(conn.cursor()) as c:
        c.execute(query)
        results = c.fetchall()

    teams = []
    for row in results:
        team = make_team(row)
        teams.append(team)
    return teams

def get_team(id):
    query = '''SELECT teamID, teamName, wins, losses, ties, passAtt, passCmp,
                     passYards, passTD, passINT
               FROM Teams
               WHERE teamID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(query, (id,))
        row = c.fetchone()
        if row:
            team = make_team(row)
            return team
        else:
            return None

def add_team(team):
    sql = '''INSERT INTO Teams
               (teamID, teamName, wins, losses, ties, passAtt, passCmp,
               passYards, passTD, passINT) 
             VALUES
               (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (team.teamID, team.teamName, team.wins, team.losses,
                        team.ties, team.passAtt, team.passCmp, team.passYards,
                        team.passTD, team.passINT))
        conn.commit()

def delete_team(team):
    sql = '''DELETE FROM Teams WHERE teamID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (team.teamID,))
        conn.commit()

def update_team(team):
    sql = '''UPDATE Teams
             SET wins = ?, losses = ?, ties = ?, passAtt = ?, passCmp = ?,
                 passYards = ?, passTD = ?, passINT = ?
             WHERE teamID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (team.wins, team.losses, team.ties, team.passAtt,
                        team.passCmp, team.passYards,
                        team.passTD, team.passINT, team.teamID))
        conn.commit()

def main():
    connect()
    teams = get_teams()
    for team in teams:
        print(team.teamID, team.teamName, team.wins, team.losses,
              team.ties, team.winPerc, team.passAtt, team.passCmp,
              team.cmpPerc, team.passYards, team.yardsPerAtt,
              team.passTD, team.passINT)

if __name__ == "__main__":
    main()
